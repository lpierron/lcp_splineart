# Author:
#     Loic Gouarin <loic.gouarin@gmail.com>
#
# License: BSD 3 clause
"""
spline
"""
from .spline import spline
from .splint import splint
