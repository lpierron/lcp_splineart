# Author:
#     Loic Gouarin <loic.gouarin@gmail.com>
#
# License: BSD 3 clause
"""
color
"""
DEFAULT_COLOR = (0.0, 0.41568627450980394, 0.61960784313725492, 1.0)
